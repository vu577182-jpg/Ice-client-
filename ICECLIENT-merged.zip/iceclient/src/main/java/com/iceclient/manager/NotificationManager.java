package com.iceclient.manager;

import com.iceclient.module.Module;
import com.iceclient.module.ModuleManager;
import com.iceclient.module.hud.NotificationHud;
import com.iceclient.util.Animation;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class NotificationManager {
    public enum Type {
        INFO(Theme.PRIMARY), OK(Theme.OK), WARN(Theme.WARN), ERROR(Theme.DANGER);
        public final int color;
        Type(int color) { this.color = color; }
    }

    private static final class Entry {
        final String title, message;
        final Type type;
        final long created = System.currentTimeMillis();
        final long lifetime;
        final Animation slide = new Animation(0f, 12f);

        Entry(String title, String message, Type type, long lifetime) {
            this.title = title; this.message = message; this.type = type; this.lifetime = lifetime;
        }
    }

    private static final List<Entry> ENTRIES = new ArrayList<>();
    private static final int MAX = 6;

    private NotificationManager() {}

    public static synchronized void push(String title, String message, Type type) {
        ENTRIES.add(new Entry(title, message, type, 3200));
        while (ENTRIES.size() > MAX) ENTRIES.remove(0);
    }

    public static void info(String t, String m) { push(t, m, Type.INFO); }
    public static void warn(String t, String m) { push(t, m, Type.WARN); }
    public static void error(String t, String m) { push(t, m, Type.ERROR); }

    public static void toggled(Module m) {
        push(m.name, m.isEnabled() ? "Da bat" : "Da tat", m.isEnabled() ? Type.OK : Type.INFO);
    }

    /** True if the Notification HUD module is currently enabled. */
    private static boolean shown() {
        NotificationHud hud = ModuleManager.get(NotificationHud.class);
        return hud != null && hud.isEnabled();
    }

    public static synchronized void render(GuiGraphicsExtractor g) {
        if (!shown()) return;
        int sw = g.guiWidth(), sh = g.guiHeight();
        long now = System.currentTimeMillis();
        int y = sh - 40;
        Iterator<Entry> it = ENTRIES.iterator();
        List<Entry> alive = new ArrayList<>();
        while (it.hasNext()) {
            Entry e = it.next();
            boolean expired = now - e.created > e.lifetime;
            e.slide.set(expired ? 0f : 1f);
            float s = e.slide.get();
            if (expired && s <= 0.01f) { it.remove(); continue; }
            alive.add(e);
        }
        for (int i = alive.size() - 1; i >= 0; i--) {
            Entry e = alive.get(i);
            float s = e.slide.get();
            int w = Math.max(120, Math.max(Render2D.width(e.title), Render2D.width(e.message)) + 24);
            int h = 28;
            int x = sw - (int) ((w + 8) * s);
            y -= h + 4;
            Render2D.panel(g, x, y, w, h, Theme.alpha(Theme.BG, 0xE6), Theme.BORDER);
            Render2D.rect(g, x + 1, y + 1, 2, h - 2, e.type.color);
            Render2D.text(g, e.title, x + 9, y + 5, Theme.TEXT);
            Render2D.text(g, e.message, x + 9, y + 16, Theme.MUTED);
            float left = 1f - Math.min(1f, (now - e.created) / (float) e.lifetime);
            Render2D.rect(g, x + 3, y + h - 2, (int) ((w - 6) * left), 1, Theme.alpha(e.type.color, 0xAA));
        }
    }
}
