package com.iceclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;

public final class TargetUtil {
    private TargetUtil() {}

    /** Closest living non-spectator player (including FakePlayer) within range, excluding ourselves. */
    public static Player nearestPlayer(double range) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer self = mc.player;
        Player best = null;
        double bestDist = range * range;
        for (Player p : mc.level.getEntitiesOfClass(Player.class, self.getBoundingBox().inflate(range))) {
            if (p == self || !p.isAlive() || p.isSpectator()) continue;
            double d = self.distanceToSqr(p);
            if (d < bestDist) { bestDist = d; best = p; }
        }
        return best;
    }
}
