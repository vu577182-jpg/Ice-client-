package com.iceclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.function.Predicate;

public final class InventoryUtil {
    private InventoryUtil() {}

    public static boolean isItem(ItemStack stack, Item item) {
        return !stack.isEmpty() && stack.getItem() == item;
    }

    public static int findHotbar(Item item) {
        return findHotbar(s -> isItem(s, item));
    }

    public static int findHotbar(Predicate<ItemStack> filter) {
        Inventory inv = Minecraft.getInstance().player.getInventory();
        for (int i = 0; i < 9; i++) if (filter.test(inv.getItem(i))) return i;
        return -1;
    }

    public static int selected() {
        return Minecraft.getInstance().player.getInventory().getSelectedSlot();
    }

    public static void select(int slot) {
        if (slot < 0 || slot > 8) return;
        Minecraft.getInstance().player.getInventory().setSelectedSlot(slot);
    }
}
