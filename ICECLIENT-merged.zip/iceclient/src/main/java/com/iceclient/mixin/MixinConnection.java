package com.iceclient.mixin;

import com.iceclient.client.Ice;
import com.iceclient.event.PacketEvent;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Connection.class)
public abstract class MixinConnection {
    @Inject(method = "channelRead0", at = @At("HEAD"), cancellable = true)
    private void iceclient$onReceive(ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci) {
        PacketEvent.Receive event = Ice.EVENTS.post(new PacketEvent.Receive(packet));
        if (event.isCancelled()) ci.cancel();
    }
}
