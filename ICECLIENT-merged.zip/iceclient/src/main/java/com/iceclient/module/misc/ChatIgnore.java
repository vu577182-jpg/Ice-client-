package com.iceclient.module.misc;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.StringSetting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Hides chat lines that contain ignored players or words. Filtering is performed by {@link #shouldHide}. */
public final class ChatIgnore extends Module {
    private final StringSetting players = add(new StringSetting("Players", "Comma separated player names to hide", ""));
    private final StringSetting words = add(new StringSetting("Words", "Comma separated words to hide", ""));

    public ChatIgnore() {
        super("ChatIgnore", "An tin nhan chua ten nguoi choi hoac tu khoa.", Category.MISC);
    }

    @Override protected boolean requiresWorld() { return false; }

    private static List<String> split(String s) {
        List<String> out = new ArrayList<>();
        for (String part : s.split(",")) {
            String t = part.trim().toLowerCase(Locale.ROOT);
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    public boolean shouldHide(String message) {
        if (!isEnabled()) return false;
        String lower = message.toLowerCase(Locale.ROOT);
        for (String s : split(players.get())) if (lower.contains(s)) return true;
        for (String s : split(words.get())) if (lower.contains(s)) return true;
        return false;
    }
}
