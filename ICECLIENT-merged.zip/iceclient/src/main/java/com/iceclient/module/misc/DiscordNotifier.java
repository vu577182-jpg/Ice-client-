package com.iceclient.module.misc;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.StringSetting;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.network.chat.Component;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * Gửi tin nhắn tới Discord webhook qua lệnh client /dn &lt;text&gt;.
 * Port từ DiscordNotifierMod.class (giữ webhook mặc định người dùng cung cấp).
 */
public final class DiscordNotifier extends Module {

    private final StringSetting webhook = add(new StringSetting(
            "Webhook",
            "Discord webhook URL",
            "https://discord.com/api/webhooks/1568215511375020113/ImYtJMVFcLIahDaWBzXpbuoSVB8yUvret7XLKLrOLHTLqHEoGbLevq_9Vo62q2AjtZnR"
    ));
    private final BooleanSetting enabledCmd = add(new BooleanSetting(
            "Command",
            "Cho phép lệnh /dn khi module bật",
            true
    ));

    private static boolean commandRegistered;

    public DiscordNotifier() {
        super("DiscordNotifier", "Gửi tin nhắn tới Discord webhook bằng lệnh /dn.", Category.MISC);
        setEnabledSilently(true); // luôn bật, module ẩn
        registerCommandOnce();
    }

    @Override
    public boolean isHidden() {
        return true; // không hiện trên ClickGUI / ArrayList
    }

    @Override
    protected boolean requiresWorld() {
        return false;
    }

    private void registerCommandOnce() {
        if (commandRegistered) return;
        commandRegistered = true;

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                    ClientCommandManager.literal("dn")
                            .then(ClientCommandManager.argument("text", StringArgumentType.greedyString())
                                    .executes(ctx -> {
                                        DiscordNotifier self = com.iceclient.module.ModuleManager.get(DiscordNotifier.class);
                                        if (self == null || !self.isEnabled() || !self.enabledCmd.get()) {
                                            ctx.getSource().sendFeedback(Component.literal("§cDiscordNotifier đang tắt."));
                                            return 0;
                                        }
                                        String text = StringArgumentType.getString(ctx, "text");
                                        String playerName = "unknown";
                                        try {
                                            if (self.mc.player != null) {
                                                playerName = self.mc.player.getName().getString();
                                            }
                                        } catch (Exception ignored) {}
                                        final String name = playerName;
                                        final String msg = text;
                                        new Thread(() -> self.sendToDiscord(name, msg), "DiscordNotifier").start();
                                        ctx.getSource().sendFeedback(Component.literal("§aĐã gửi tới Discord."));
                                        return 1;
                                    }))
            );
        });
    }

    private void sendToDiscord(String playerName, String message) {
        String urlStr = webhook.get();
        if (urlStr == null || urlStr.isBlank() || !urlStr.startsWith("https://discord.com/api/webhooks/")) {
            System.err.println("[DiscordNotifier] Webhook URL không hợp lệ");
            return;
        }
        try {
            URL url = URI.create(urlStr).toURL();
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("User-Agent", "DiscordNotifierMod/1.0");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            String instant = Instant.now().toString();
            String title = "ICECLIENT • " + playerName;
            String footer = "player: " + playerName;
            String timeStr = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")
                    .withZone(ZoneId.of("Asia/Ho_Chi_Minh"))
                    .format(Instant.now());

            // JSON embed tương tự bản gốc
            String json = "{"
                    + "\"username\":\"ICECLIENT\","
                    + "\"embeds\":[{"
                    + "\"title\":\"" + escape(title) + "\","
                    + "\"description\":\"" + escape(message) + "\","
                    + "\"color\":5793266,"
                    + "\"footer\":{\"text\":\"" + escape(footer) + "\"},"
                    + "\"timestamp\":\"" + escape(instant) + "\","
                    + "\"fields\":[{\"name\":\"Thời gian\",\"value\":\"" + escape(timeStr) + "\",\"inline\":true}]"
                    + "}]"
                    + "}";

            byte[] body = json.getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body);
            }
            conn.getResponseCode(); // force request
            conn.disconnect();
        } catch (Exception e) {
            System.err.println("[DiscordNotifier] " + e.getMessage());
        }
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
