package com.iceclient.module.misc;

import com.iceclient.manager.NotificationManager;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.StringSetting;

import java.util.Locale;

/** Pops a notification when chat mentions you or a keyword. */
public final class ChatNotify extends Module {
    private final BooleanSetting ownName = add(new BooleanSetting("OwnName", "Notify when your name is mentioned", true));
    private final StringSetting keywords = add(new StringSetting("Keywords", "Comma separated extra keywords", ""));

    public ChatNotify() {
        super("ChatNotify", "Thong bao khi chat nhac toi ban hoac tu khoa.", Category.MISC);
    }

    @Override protected boolean requiresWorld() { return false; }

    public void onChat(String message) {
        if (!isEnabled()) return;
        String lower = message.toLowerCase(Locale.ROOT);
        if (ownName.on() && mc.player != null) {
            String me = mc.player.getGameProfile().name().toLowerCase(Locale.ROOT);
            if (!me.isEmpty() && lower.contains(me)) {
                NotificationManager.info("Chat", trim(message));
                return;
            }
        }
        for (String k : keywords.get().split(",")) {
            String t = k.trim().toLowerCase(Locale.ROOT);
            if (!t.isEmpty() && lower.contains(t)) {
                NotificationManager.info("Chat: " + t, trim(message));
                return;
            }
        }
    }

    private static String trim(String s) { return s.length() > 48 ? s.substring(0, 45) + "..." : s; }
}
