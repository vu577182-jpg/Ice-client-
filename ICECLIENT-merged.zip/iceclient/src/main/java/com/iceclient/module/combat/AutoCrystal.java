package com.iceclient.module.combat;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.BlockUtil;
import com.iceclient.util.InventoryUtil;
import com.iceclient.util.RotationUtil;
import com.iceclient.util.TargetUtil;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Places end crystals next to the nearest player and detonates them. */
public final class AutoCrystal extends Module {
    private final NumberSetting targetRange = add(new NumberSetting("TargetRange", "Max distance to pick a target", 10, 3, 16, 0.5));
    private final NumberSetting placeRange = add(new NumberSetting("PlaceRange", "Max placement reach", 4.5, 1, 6, 0.1));
    private final NumberSetting breakRange = add(new NumberSetting("BreakRange", "Max attack reach", 4.5, 1, 6, 0.1));
    private final NumberSetting minSelf = add(new NumberSetting("MinSelfDist", "Never use crystals closer than this to you", 3.0, 1, 8, 0.5));
    private final NumberSetting minHealth = add(new NumberSetting("MinHealth", "Stop when your health is below this", 8, 1, 20, 1));
    private final NumberSetting placeDelay = add(new NumberSetting("PlaceDelay", "Ticks between placements", 2, 0, 10, 1));
    private final NumberSetting breakDelay = add(new NumberSetting("BreakDelay", "Ticks between attacks", 1, 0, 10, 1));
    private final BooleanSetting place = add(new BooleanSetting("Place", "Place crystals", true));
    private final BooleanSetting breakCrystals = add(new BooleanSetting("Break", "Break crystals", true));
    private final BooleanSetting autoSwitch = add(new BooleanSetting("AutoSwitch", "Switch to crystals on the hotbar", true));
    private final BooleanSetting rotate = add(new BooleanSetting("Rotate", "Send rotation packets", true));

    private int placeTimer, breakTimer;

    public AutoCrystal() {
        super("AutoCrystal", "Tu dong dat va no end crystal quanh muc tieu.", Category.COMBAT);
    }

    @Override
    protected void onEnable() { placeTimer = 0; breakTimer = 0; }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p.getHealth() < minHealth.f()) return;
        Player target = TargetUtil.nearestPlayer(targetRange.d());
        if (target == null) return;

        if (breakTimer > 0) breakTimer--;
        if (placeTimer > 0) placeTimer--;
        if (breakCrystals.on() && breakTimer == 0) breakCrystal(p, target);
        if (place.on() && placeTimer == 0) placeCrystal(p, target);
    }

    private void breakCrystal(LocalPlayer p, Player target) {
        List<EndCrystal> crystals = mc.level.getEntitiesOfClass(EndCrystal.class, p.getBoundingBox().inflate(breakRange.d()));
        EndCrystal best = null;
        double bestDist = Double.MAX_VALUE;
        double minSq = minSelf.d() * minSelf.d();
        for (EndCrystal c : crystals) {
            if (c.isRemoved()) continue;
            if (p.distanceToSqr(c) < minSq) continue;
            if (p.getEyePosition().distanceToSqr(c.getBoundingBox().getCenter()) > breakRange.d() * breakRange.d()) continue;
            double d = target.distanceToSqr(c);
            if (d < 36 && d < bestDist) { bestDist = d; best = c; }
        }
        if (best == null) return;
        if (rotate.on()) RotationUtil.face(best.getBoundingBox().getCenter());
        mc.gameMode.attack(p, best);
        p.swing(InteractionHand.MAIN_HAND);
        breakTimer = breakDelay.i();
    }

    private void placeCrystal(LocalPlayer p, Player target) {
        InteractionHand hand;
        int restore = -1;
        if (InventoryUtil.isItem(p.getOffhandItem(), Items.END_CRYSTAL)) {
            hand = InteractionHand.OFF_HAND;
        } else if (InventoryUtil.isItem(p.getMainHandItem(), Items.END_CRYSTAL)) {
            hand = InteractionHand.MAIN_HAND;
        } else if (autoSwitch.on()) {
            int slot = InventoryUtil.findHotbar(Items.END_CRYSTAL);
            if (slot == -1) return;
            restore = InventoryUtil.selected();
            InventoryUtil.select(slot);
            hand = InteractionHand.MAIN_HAND;
        } else {
            return;
        }

        BlockPos base = findBase(p, target);
        if (base != null && BlockUtil.use(base, Direction.UP, hand, rotate.on())) {
            placeTimer = placeDelay.i();
        }
        if (restore != -1) InventoryUtil.select(restore);
    }

    private BlockPos findBase(LocalPlayer p, Player target) {
        BlockPos origin = target.blockPosition();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        double minSq = minSelf.d() * minSelf.d();
        double reachSq = placeRange.d() * placeRange.d();
        Vec3 targetPos = target.position();

        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = -2; dy <= 0; dy++) {
                    BlockPos base = origin.offset(dx, dy, dz);
                    var block = mc.level.getBlockState(base).getBlock();
                    if (block != Blocks.OBSIDIAN && block != Blocks.BEDROCK) continue;
                    if (!BlockUtil.isAir(base.above()) || !BlockUtil.isAir(base.above(2))) continue;

                    Vec3 crystal = new Vec3(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
                    if (p.getEyePosition().distanceToSqr(crystal) > reachSq) continue;
                    if (p.position().distanceToSqr(crystal) < minSq) continue;
                    if (hasEntity(base)) continue;

                    double score = crystal.distanceToSqr(targetPos);
                    if (score < bestScore) { bestScore = score; best = base; }
                }
            }
        }
        return best;
    }

    private boolean hasEntity(BlockPos base) {
        AABB box = new AABB(base.getX(), base.getY() + 1, base.getZ(), base.getX() + 1, base.getY() + 3, base.getZ() + 1);
        for (Entity e : mc.level.getEntitiesOfClass(Entity.class, box)) {
            if (!(e instanceof ItemEntity)) return true;
        }
        return false;
    }
}
