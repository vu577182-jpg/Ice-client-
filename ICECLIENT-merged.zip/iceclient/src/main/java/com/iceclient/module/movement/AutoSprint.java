package com.iceclient.module.movement;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import net.minecraft.client.player.LocalPlayer;

public final class AutoSprint extends Module {
    private final BooleanSetting omni = add(new BooleanSetting("Omni", "Sprint in every movement direction", false));

    public AutoSprint() {
        super("AutoSprint", "Tu dong chay nhanh khi di chuyen.", Category.MOVEMENT);
    }

    @Override public String info() { return omni.on() ? "Omni" : "Forward"; }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (mc.gui.screen() != null) return;
        boolean moving = mc.options.keyUp.isDown()
                || (omni.on() && (mc.options.keyDown.isDown() || mc.options.keyLeft.isDown() || mc.options.keyRight.isDown()));
        boolean allowed = moving && !p.isUsingItem() && !p.horizontalCollision;
        if (allowed) mc.options.keySprint.setDown(true);
    }

    @Override
    protected void onDisable() {
        if (mc.options != null) mc.options.keySprint.setDown(false);
    }
}
