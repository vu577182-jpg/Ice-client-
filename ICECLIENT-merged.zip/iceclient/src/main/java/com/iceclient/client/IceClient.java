package com.iceclient.client;

import com.iceclient.config.ConfigManager;
import com.iceclient.module.ModuleManager;
import com.iceclient.module.misc.ChatIgnore;
import com.iceclient.module.misc.ChatNotify;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.resources.Identifier;

public final class IceClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        if (!ConfigManager.load("default")) ConfigManager.save("default");

        ClientTickEvents.END_CLIENT_TICK.register(mc -> ModuleManager.tick());

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("iceclient", "hud"),
                (graphics, delta) -> ModuleManager.render2D(graphics));

        // Incoming chat: ChatIgnore may hide a line, ChatNotify may react to it.
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signed, sender, params, receptionTimestamp) -> {
            String text = message.getString();
            ChatNotify notify = ModuleManager.get(ChatNotify.class);
            ChatIgnore ignore = ModuleManager.get(ChatIgnore.class);
            if (ignore != null && ignore.shouldHide(text)) return false;
            if (notify != null) notify.onChat(text);
            return true;
        });
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (overlay) return true;
            String text = message.getString();
            ChatNotify notify = ModuleManager.get(ChatNotify.class);
            ChatIgnore ignore = ModuleManager.get(ChatIgnore.class);
            if (ignore != null && ignore.shouldHide(text)) return false;
            if (notify != null) notify.onChat(text);
            return true;
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> ConfigManager.save("default"));
        Ice.LOGGER.info("{} {} initialised", Ice.NAME, Ice.VERSION);
    }
}
