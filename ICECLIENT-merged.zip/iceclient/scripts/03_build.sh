#!/usr/bin/env bash
# Step 3 - build with Gradle, copy the result to ICECLIENT.jar, verify it.
set -uo pipefail
cd "$(dirname "$0")/.."
source scripts/env.sh
[ -x ./gradlew ] || { echo "[ERR] Chay scripts/02_bootstrap.sh truoc"; exit 1; }

./gradlew --no-daemon clean build 2>&1 | tee build.log
status=${PIPESTATUS[0]}
if [ "$status" -ne 0 ]; then
  echo
  echo "[FAIL] Gradle build loi. Loi dau tien:"
  grep -nE "error:|FAILED|What went wrong|Could not" build.log | head -25
  echo "Gui toi file build.log (hoac 40 dong loi o tren) de sua."
  exit 1
fi
JAR=$(ls build/libs/*.jar 2>/dev/null | grep -vE 'sources|javadoc|dev' | head -1)
[ -n "$JAR" ] || { echo "[FAIL] Khong thay jar trong build/libs"; exit 1; }
cp "$JAR" ICECLIENT.jar
echo "[OK] $JAR -> ICECLIENT.jar"
bash scripts/04_verify.sh
