#!/usr/bin/env bash
# Step 4 - inspect ICECLIENT.jar (never claim success without this).
set -uo pipefail
cd "$(dirname "$0")/.."
source scripts/env.sh
JAR=ICECLIENT.jar
[ -f "$JAR" ] || { echo "[FAIL] $JAR khong ton tai"; exit 1; }
fail=0
check() { if "$@" >/dev/null 2>&1; then echo "[OK]   $DESC"; else echo "[FAIL] $DESC"; fail=1; fi; }

DESC="fabric.mod.json";            check unzip -p "$JAR" fabric.mod.json
DESC="iceclient.mixins.json";      check unzip -p "$JAR" iceclient.mixins.json
DESC="IceClient entrypoint class"; check unzip -p "$JAR" com/iceclient/client/IceClient.class
for c in MixinKeyboardHandler MixinConnection AccessorOptionInstance AccessorClientboundSetEntityMotionPacket AccessorClientboundExplodePacket; do
  DESC="mixin $c"; check unzip -p "$JAR" com/iceclient/mixin/$c.class
done
echo "Classes: $(unzip -l "$JAR" | grep -c '\.class')"
echo "Modules: $(unzip -l "$JAR" | grep -cE 'com/iceclient/module/(combat|movement|player|render|hud|misc|client)/[A-Za-z]+\.class')"
echo "Java class version: $(javap -v -cp "$JAR" com.iceclient.client.IceClient 2>/dev/null | grep 'major version')  (69 = Java 25)"
echo "Size: $(du -h "$JAR" | cut -f1)"
if [ $fail -eq 0 ]; then
  echo; echo "JAR hop le ve cau truc. Buoc con lai: chay thu trong Minecraft 26.2 va doc logs/latest.log (script 05)."
else
  echo; echo "JAR CHUA DAT."; exit 1
fi
