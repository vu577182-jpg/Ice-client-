#!/usr/bin/env bash
# Step 5 - after launching Minecraft 26.2, filter the log for ICECLIENT / Mixin problems.
# Usage: bash scripts/05_checklog.sh /path/to/.minecraft/logs/latest.log
LOG="${1:-logs/latest.log}"
[ -f "$LOG" ] || { echo "Khong thay $LOG"; exit 1; }
grep -nEi "iceclient|InvalidInjection|MixinApply|Mixin transformation|Exception|Caused by" "$LOG" | head -60
