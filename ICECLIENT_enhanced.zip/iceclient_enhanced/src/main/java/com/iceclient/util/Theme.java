package com.iceclient.util;

/** ICE PRO palette (ARGB) — enhanced with glow, accent, and chroma support. */
public final class Theme {
    // ---- base palette -------------------------------------------------------
    public static final int BG        = 0xFF060C18;
    public static final int BG_LIGHT  = 0xFF0B1422;
    public static final int CARD      = 0xFF0D1726;
    public static final int CARD_HOVER= 0xFF132236;
    public static final int PRIMARY   = 0xFF55BFFF;
    public static final int SECONDARY = 0xFFA8DFFF;
    public static final int BORDER    = 0xFF233650;
    public static final int TEXT      = 0xFFEAF6FF;
    public static final int MUTED     = 0xFF6E8AA0;
    public static final int TRACK_OFF = 0xFF192840;
    public static final int WARN      = 0xFFFFC857;
    public static final int DANGER    = 0xFFFF6B7A;
    public static final int OK        = 0xFF6BFFB0;

    // ---- glow / accent -------------------------------------------------------
    /** Soft neon cyan glow — use with low alpha for bloom effects. */
    public static final int GLOW      = 0xFF00E5FF;
    /** Deep blue shadow for layered backgrounds. */
    public static final int SHADOW    = 0xFF020810;
    /** Accent orange for health / critical indicators. */
    public static final int ACCENT_HP = 0xFFFF7043;
    /** Accent green for armour / shield bars. */
    public static final int ACCENT_ARM= 0xFF69FF91;
    /** Accent purple for magic / effect timers. */
    public static final int ACCENT_FX = 0xFFCE93D8;
    /** Ping good (green). */
    public static final int PING_GOOD = 0xFF69FF91;
    /** Ping mid (yellow). */
    public static final int PING_MID  = 0xFFFFD740;
    /** Ping bad (red). */
    public static final int PING_BAD  = 0xFFFF6B7A;

    private Theme() {}

    // ---- helpers -------------------------------------------------------------

    public static int alpha(int rgb, int a) {
        return ((a & 0xFF) << 24) | (rgb & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int)(((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int ar = (int)(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = (int)(((a >> 8)  & 255) + (((b >> 8)  & 255) - ((a >> 8)  & 255)) * t);
        int ab = (int)((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    /**
     * Rainbow / chroma color cycling. hue in [0,1], sat/val in [0,1].
     * Returns fully-opaque ARGB.
     */
    public static int chroma(float hue, float sat, float val) {
        hue = hue - (float) Math.floor(hue);
        int h = (int)(hue * 6);
        float f = hue * 6 - h;
        float p = val * (1 - sat);
        float q = val * (1 - f * sat);
        float t = val * (1 - (1 - f) * sat);
        float r, g, b;
        switch (h % 6) {
            case 0 -> { r = val; g = t;   b = p; }
            case 1 -> { r = q;   g = val; b = p; }
            case 2 -> { r = p;   g = val; b = t; }
            case 3 -> { r = p;   g = q;   b = val; }
            case 4 -> { r = t;   g = p;   b = val; }
            default-> { r = val; g = p;   b = q; }
        }
        return 0xFF000000 | ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

    /** Current chroma color based on wall-clock time. offset shifts the phase [0,1]. */
    public static int chromaNow(float offset) {
        float hue = ((System.currentTimeMillis() % 4000L) / 4000f) + offset;
        return chroma(hue, 0.65f, 1f);
    }

    /** Health color: green → yellow → red based on fraction [0,1]. */
    public static int health(float fraction) {
        if (fraction > 0.5f) return lerp(WARN, OK, (fraction - 0.5f) * 2f);
        return lerp(DANGER, WARN, fraction * 2f);
    }

    /** Ping color. */
    public static int ping(int ms) {
        if (ms < 80)  return PING_GOOD;
        if (ms < 180) return PING_MID;
        return PING_BAD;
    }
}
