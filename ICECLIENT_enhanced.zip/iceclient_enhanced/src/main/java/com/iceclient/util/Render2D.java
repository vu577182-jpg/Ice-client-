package com.iceclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Render2D — enhanced primitive library for ICECLIENT.
 *
 * New additions over the original:
 *  - roundedRect / roundedPanel   (multi-pixel corner radius)
 *  - gradientH / gradientV        (horizontal / vertical 2-stop gradient fills)
 *  - glowRect                     (layered soft glow by drawing alpha-faded outsets)
 *  - bar                          (progress bar with optional glow on the fill)
 *  - triangle                     (right-pointing or down-pointing indicator)
 *  - centeredText / shadowCenteredText
 *  - All existing helpers kept intact.
 */
public final class Render2D {
    private Render2D() {}

    // =========================================================================
    // Basic fills
    // =========================================================================

    public static void rect(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        if (w <= 0 || h <= 0) return;
        g.fill(x, y, x + w, y + h, color);
    }

    public static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x,         y,         x + w,     y + 1,     color);
        g.fill(x,         y + h - 1, x + w,     y + h,     color);
        g.fill(x,         y + 1,     x + 1,     y + h - 1, color);
        g.fill(x + w - 1, y + 1,     x + w,     y + h - 1, color);
    }

    /** Classic 1px chamfer panel (original helper, kept for compatibility). */
    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, int bg, int border) {
        if (w < 4 || h < 4) { rect(g, x, y, w, h, bg); return; }
        g.fill(x + 1, y + 1,     x + w - 1, y + h - 1, bg);
        g.fill(x + 1, y,         x + w - 1, y + 1,     border);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h,     border);
        g.fill(x,     y + 1,     x + 1,     y + h - 1, border);
        g.fill(x + w - 1, y + 1, x + w,     y + h - 1, border);
    }

    // =========================================================================
    // Rounded rectangle (integer radius via pixel-art circle approximation)
    // =========================================================================

    /**
     * Filled rounded rectangle. Radius is clamped to half min(w,h).
     * Drawn as stacked horizontal spans — no native GL needed, pure fill calls.
     */
    public static void roundedRect(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) { rect(g, x, y, w, h, color); return; }

        // Centre fill (vertical strip)
        g.fill(x + r, y,     x + w - r, y + h,     color);
        // Left and right pillars
        g.fill(x,         y + r, x + r,     y + h - r, color);
        g.fill(x + w - r, y + r, x + w,     y + h - r, color);

        // Corners: circle quadrant rasterisation
        for (int row = 0; row < r; row++) {
            int dx = (int) Math.round(Math.sqrt((double) r * r - (double) (r - 1 - row) * (r - 1 - row)));
            // top-left
            g.fill(x + r - dx, y + row, x + r, y + row + 1, color);
            // top-right
            g.fill(x + w - r, y + row, x + w - r + dx, y + row + 1, color);
            // bottom-left
            g.fill(x + r - dx, y + h - row - 1, x + r, y + h - row, color);
            // bottom-right
            g.fill(x + w - r, y + h - row - 1, x + w - r + dx, y + h - row, color);
        }
    }

    /**
     * Rounded panel: filled bg + 1px border outline that also follows the radius.
     */
    public static void roundedPanel(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int bg, int border) {
        roundedRect(g, x,     y,     w,     h,     r,     border);
        roundedRect(g, x + 1, y + 1, w - 2, h - 2, r - 1, bg);
    }

    // =========================================================================
    // Gradients
    // =========================================================================

    public static void gradientH(GuiGraphicsExtractor g, int x, int y, int w, int h, int left, int right) {
        if (w <= 0 || h <= 0) return;
        g.fillGradient(x, y, x + w, y + h, left, right);
    }

    public static void gradientV(GuiGraphicsExtractor g, int x, int y, int w, int h, int top, int bottom) {
        if (w <= 0 || h <= 0) return;
        // fillGradient in MC 1.21 goes left→right; use rotated approach via per-row fills
        // Approximate as horizontal gradient along the vertical axis:
        for (int row = 0; row < h; row++) {
            int c = Theme.lerp(top, bottom, row / (float) (h - 1));
            g.fill(x, y + row, x + w, y + row + 1, c);
        }
    }

    // =========================================================================
    // Glow effect (soft bloom via layered alpha-faded outsets)
    // =========================================================================

    /**
     * Draws concentric outlines fading outward to simulate a glow.
     * @param radius number of outset pixels (2–6 looks good)
     * @param color  base glow color (alpha will be overridden)
     */
    public static void glowRect(GuiGraphicsExtractor g, int x, int y, int w, int h, int radius, int color) {
        for (int i = 1; i <= radius; i++) {
            int a = (int)(80 * (1f - (float) i / (radius + 1)));
            int c = Theme.alpha(color, a);
            outline(g, x - i, y - i, w + i * 2, h + i * 2, c);
        }
    }

    /** Rounded-corner glow. */
    public static void glowRounded(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int radius, int color) {
        for (int i = 1; i <= radius; i++) {
            int a = (int)(70 * (1f - (float) i / (radius + 1)));
            int c = Theme.alpha(color, a);
            roundedRect(g, x - i, y - i, w + i * 2, h + i * 2, r + i, c);
        }
    }

    // =========================================================================
    // Progress bar
    // =========================================================================

    /**
     * Horizontal progress bar with optional fill glow.
     * @param progress 0..1
     * @param glow     whether to draw glow on the filled portion
     */
    public static void bar(GuiGraphicsExtractor g, int x, int y, int w, int h,
                           float progress, int trackColor, int fillColor, boolean glow) {
        progress = Math.max(0f, Math.min(1f, progress));
        roundedRect(g, x, y, w, h, h / 2, trackColor);
        int fw = (int)(w * progress);
        if (fw > 0) {
            roundedRect(g, x, y, fw, h, h / 2, fillColor);
            if (glow) glowRect(g, x, y, fw, h, 2, fillColor);
        }
    }

    // =========================================================================
    // Triangle indicators
    // =========================================================================

    /** Small right-pointing triangle (▶) at (x,y), size px. */
    public static void triangleRight(GuiGraphicsExtractor g, int x, int y, int size, int color) {
        for (int i = 0; i < size; i++) {
            int len = i < size / 2 ? i + 1 : size - i;
            g.fill(x + (size / 2 - len / 2), y + i, x + (size / 2 - len / 2) + len, y + i + 1, color);
        }
    }

    /** Small down-pointing triangle (▼) at (x,y), size px. */
    public static void triangleDown(GuiGraphicsExtractor g, int x, int y, int size, int color) {
        for (int i = 0; i < size; i++) {
            int w = size - i * 2;
            if (w <= 0) break;
            g.fill(x + i, y + i, x + i + w, y + i + 1, color);
        }
    }

    // =========================================================================
    // Text helpers
    // =========================================================================

    public static void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(Minecraft.getInstance().font, s, x, y, color, false);
    }

    public static void shadowText(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(Minecraft.getInstance().font, s, x, y, color, true);
    }

    public static void centeredText(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        text(g, s, cx - width(s) / 2, y, color);
    }

    public static void shadowCenteredText(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        shadowText(g, s, cx - width(s) / 2, y, color);
    }

    public static int width(String s) { return Minecraft.getInstance().font.width(s); }

    public static String trim(String s, int maxWidth) {
        if (width(s) <= maxWidth) return s;
        while (s.length() > 1 && width(s + "...") > maxWidth) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    // =========================================================================
    // Ice shard (original, kept intact)
    // =========================================================================

    /** Faceted vertical ice shard centred on (cx, cy). */
    public static void shard(GuiGraphicsExtractor g, int cx, int cy, int hw, int hh, int alpha) {
        int body  = Theme.alpha(0x7FD0FF, alpha);
        int facet = Theme.alpha(0xFFFFFF, alpha / 2);
        for (int r = -hh; r <= hh; r++) {
            int w = (int) Math.round(hw * (1.0 - (double) Math.abs(r) / (hh + 1)));
            if (w <= 0) continue;
            g.fill(cx - w,  cy + r, cx + w + 1, cy + r + 1, body);
            g.fill(cx - w,  cy + r, cx,          cy + r + 1, facet);
        }
        g.fill(cx, cy - hh, cx + 1, cy + hh + 1, Theme.alpha(0xFFFFFF, Math.min(255, alpha + 16)));
    }
}
