package com.iceclient.module.render;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * Highlights 1×1 holes surrounded by blast-resistant blocks (obsidian / bedrock)
 * on the HUD as 2D markers.
 *
 * Useful for crystal PvP — quickly identify safe holes for self-surround.
 */
public final class HoleESP extends Module {
    private final NumberSetting  range    = add(new NumberSetting("Range", "Scan radius", 10, 2, 20, 1));
    private final BooleanSetting obsOnly  = add(new BooleanSetting("ObsidianOnly", "Only full obsidian holes", false));
    private final BooleanSetting showSelf = add(new BooleanSetting("ShowSelf",     "Highlight own position",    true));

    // Color: full obsidian = cyan, mixed = yellow
    private static final int COL_OBS  = 0xFF55BFFF;
    private static final int COL_MIX  = 0xFFFFD740;
    private static final int COL_SELF = 0xFF6BFFB0;

    public HoleESP() {
        super("HoleESP", "Danh dau lo obsidian an toan cho crystal PvP.", Category.RENDER);
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        if (mc.player == null || mc.level == null) return;
        int sw = g.guiWidth(), sh = g.guiHeight();

        BlockPos origin = mc.player.blockPosition();
        int r = range.i();

        List<BlockPos> holes  = new ArrayList<>();
        List<Integer>  colors = new ArrayList<>();

        for (BlockPos pos : BlockPos.betweenClosed(
                origin.offset(-r, -2, -r), origin.offset(r, 0, r))) {
            if (!isHole(pos)) continue;
            boolean fullObs = isFullObsidian(pos);
            if (obsOnly.on() && !fullObs) continue;

            boolean isSelf = showSelf.on() && pos.equals(origin.below());
            int col = isSelf ? COL_SELF : (fullObs ? COL_OBS : COL_MIX);
            holes.add(pos.immutable());
            colors.add(col);
        }

        for (int i = 0; i < holes.size(); i++) {
            int[] screen = blockToScreen(holes.get(i), sw, sh);
            if (screen == null) continue;
            int col = colors.get(i);
            int sx = screen[0], sy = screen[1];
            // Draw a small diamond ◆ marker
            drawDiamond(g, sx, sy, 5, col);
        }
    }

    /** True if the block position is air and all 4 sides + floor are blast-resistant. */
    private boolean isHole(BlockPos pos) {
        if (!mc.level.getBlockState(pos).isAir()) return false;
        return isResistant(pos.below())
            && isResistant(pos.north())
            && isResistant(pos.south())
            && isResistant(pos.east())
            && isResistant(pos.west());
    }

    private boolean isResistant(BlockPos pos) {
        BlockState s = mc.level.getBlockState(pos);
        return s.is(Blocks.OBSIDIAN)
            || s.is(Blocks.CRYING_OBSIDIAN)
            || s.is(Blocks.BEDROCK)
            || s.is(Blocks.NETHERITE_BLOCK);
    }

    private boolean isFullObsidian(BlockPos pos) {
        return isOnly(pos.below(), Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN)
            && isOnly(pos.north(), Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN)
            && isOnly(pos.south(), Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN)
            && isOnly(pos.east(),  Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN)
            && isOnly(pos.west(),  Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN);
    }

    private boolean isOnly(BlockPos pos, net.minecraft.world.level.block.Block... blocks) {
        BlockState s = mc.level.getBlockState(pos);
        for (var b : blocks) if (s.is(b)) return true;
        return false;
    }

    private int[] blockToScreen(BlockPos pos, int sw, int sh) {
        double dx = pos.getX() + 0.5 - mc.player.getX();
        double dy = pos.getY() + 1.0  - mc.player.getEyeY();
        double dz = pos.getZ() + 0.5 - mc.player.getZ();

        float yaw  = (float) Math.toRadians(mc.player.getYRot());
        float pitch= (float) Math.toRadians(mc.player.getXRot());
        double fx = -Math.sin(yaw) * Math.cos(pitch);
        double fy = -Math.sin(pitch);
        double fz =  Math.cos(yaw) * Math.cos(pitch);
        double dot = dx * fx + dy * fy + dz * fz;
        if (dot <= 0.3) return null;

        double rx = Math.cos(yaw), rz = Math.sin(yaw);
        double fovScale = sw / (2.0 * Math.tan(Math.toRadians(mc.options.fov().get() / 2.0)));
        int sx = (int)(sw / 2.0 + (dx * rx + dz * rz) / dot * fovScale);
        int sy = (int)(sh / 2.0 - dy / dot * fovScale);
        return new int[]{sx, sy};
    }

    private void drawDiamond(GuiGraphicsExtractor g, int cx, int cy, int r, int col) {
        int a = Theme.alpha(col, 0xCC);
        int f = Theme.alpha(col, 0x30);
        for (int i = -r; i <= r; i++) {
            int hw = r - Math.abs(i);
            g.fill(cx - hw, cy + i, cx + hw + 1, cy + i + 1, hw == 0 || Math.abs(i) == r ? a : f);
        }
        // Outline
        for (int i = -r; i <= r; i++) {
            int hw = r - Math.abs(i);
            g.fill(cx - hw, cy + i, cx - hw + 1, cy + i + 1, a);
            g.fill(cx + hw, cy + i, cx + hw + 1, cy + i + 1, a);
        }
    }
}
