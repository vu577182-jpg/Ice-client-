package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Animation;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.lwjgl.glfw.GLFW;

/**
 * WASD + Space + LMB + RMB keystroke visualiser.
 * Each key lights up with a smooth press animation.
 */
public final class KeystrokesHud extends Module {
    private final NumberSetting x    = add(new NumberSetting("X", "Left offset",   6,    0, 1920, 1));
    private final NumberSetting y    = add(new NumberSetting("Y", "Bottom offset", 100, 20,  400, 1));
    private final BooleanSetting showMouse = add(new BooleanSetting("Mouse", "Show LMB / RMB", true));

    // Smooth press animations per key
    private final Animation animW     = new Animation(0f, 20f);
    private final Animation animA     = new Animation(0f, 20f);
    private final Animation animS     = new Animation(0f, 20f);
    private final Animation animD     = new Animation(0f, 20f);
    private final Animation animSpace = new Animation(0f, 20f);
    private final Animation animLMB   = new Animation(0f, 20f);
    private final Animation animRMB   = new Animation(0f, 20f);

    public KeystrokesHud() {
        super("Keystrokes", "Hien thi phim bam WASD va chuot.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override protected boolean requiresWorld() { return false; }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        KeyMapping[] keys = mc.options.keyMappings;
        animW.set(mc.options.keyUp.isDown() ? 1f : 0f);
        animA.set(mc.options.keyLeft.isDown() ? 1f : 0f);
        animS.set(mc.options.keyDown.isDown() ? 1f : 0f);
        animD.set(mc.options.keyRight.isDown() ? 1f : 0f);
        animSpace.set(mc.options.keyJump.isDown() ? 1f : 0f);
        if (showMouse.on()) {
            animLMB.set(mc.options.keyAttack.isDown() ? 1f : 0f);
            animRMB.set(mc.options.keyUse.isDown() ? 1f : 0f);
        }
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        int ks = 18, gap = 2; // key size, gap
        int px = x.i();
        int py = g.guiHeight() - y.i() - (showMouse.on() ? ks * 2 + gap * 2 : ks + gap);

        // Row 1: W (centred)
        drawKey(g, px + ks + gap, py, ks, "W", animW.get());

        // Row 2: A S D
        drawKey(g, px,               py + ks + gap, ks, "A", animA.get());
        drawKey(g, px + ks + gap,    py + ks + gap, ks, "S", animS.get());
        drawKey(g, px + (ks + gap)*2, py + ks + gap, ks, "D", animD.get());

        // Row 3: Space (wide)
        int spaceW = ks * 3 + gap * 2;
        drawKey(g, px, py + (ks + gap)*2, spaceW, "___", animSpace.get());

        // Mouse row (optional)
        if (showMouse.on()) {
            int my = py + (ks + gap) * 3;
            drawKey(g, px,            my, ks + gap / 2, "L", animLMB.get());
            drawKey(g, px + ks + gap, my, ks + gap / 2, "R", animRMB.get());
        }
    }

    private void drawKey(GuiGraphicsExtractor g, int x, int y, int w, String label, float press) {
        int bg     = Theme.lerp(Theme.alpha(Theme.BG,      0xCC), Theme.alpha(Theme.PRIMARY, 0xCC), press);
        int border = Theme.lerp(Theme.BORDER,                      Theme.PRIMARY,                   press);
        int text   = Theme.lerp(Theme.MUTED,                       Theme.BG,                        press);

        Render2D.roundedPanel(g, x, y, w, 18, 3, bg, border);

        // Draw label
        if (!"___".equals(label)) {
            Render2D.centeredText(g, label, x + w / 2, y + 5, text);
        } else {
            // Space bar: draw three dots
            int dotY = y + 8;
            for (int i = 0; i < 3; i++) {
                int dot = x + w / 2 - 6 + i * 6;
                Render2D.rect(g, dot, dotY, 2, 2, text);
            }
        }
    }
}
