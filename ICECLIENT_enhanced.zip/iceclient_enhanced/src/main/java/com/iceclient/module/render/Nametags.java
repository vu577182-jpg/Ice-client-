package com.iceclient.module.render;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;

/**
 * Replaces the vanilla nametag with a custom HUD panel above each player:
 * [Name]  [HP bar]  [Ping]
 *
 * Drawn in onRender2D using the same simplified 2D projection as PlayerESP.
 */
public final class Nametags extends Module {
    private final BooleanSetting showHp   = add(new BooleanSetting("Health", "Show health bar",    true));
    private final BooleanSetting showPing = add(new BooleanSetting("Ping",   "Show latency (ms)", true));
    private final NumberSetting  range    = add(new NumberSetting("Range", "Max range", 48, 8, 128, 4));
    private final NumberSetting  scale    = add(new NumberSetting("Scale", "Tag width",  80, 40, 160, 4));

    public Nametags() {
        super("Nametags", "Hien thi ten, HP va ping tuy chinh.", Category.RENDER);
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        if (mc.player == null || mc.level == null) return;
        int sw = g.guiWidth(), sh = g.guiHeight();
        double rangeSq = range.d() * range.d();

        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            if (mc.player.distanceToSqr(p) > rangeSq) continue;

            int[] screen = worldToScreen(p, sw, sh);
            if (screen == null) continue;

            int tagW = scale.i();
            int tagH = showHp.on() ? 24 : 14;
            int tx = screen[0] - tagW / 2;
            int ty = screen[1] - tagH - 4;

            float hpFrac = p.getHealth() / p.getMaxHealth();
            int hpCol = Theme.health(hpFrac);

            // Panel
            Render2D.roundedPanel(g, tx, ty, tagW, tagH, 3,
                    Theme.alpha(Theme.BG, 0xC0), Theme.alpha(hpCol, 0x80));

            // Name
            String name = p.getName().getString();
            Render2D.shadowCenteredText(g, Render2D.trim(name, tagW - 10),
                    tx + tagW / 2, ty + 3, Theme.TEXT);

            // Ping
            if (showPing.on() && mc.getConnection() != null) {
                var info = mc.getConnection().getPlayerInfo(p.getUUID());
                if (info != null) {
                    int ms = info.getLatency();
                    String ps = ms + "ms";
                    Render2D.text(g, ps, tx + tagW - Render2D.width(ps) - 3, ty + 3,
                            Theme.alpha(Theme.ping(ms), 0xCC));
                }
            }

            // HP bar
            if (showHp.on()) {
                Render2D.bar(g, tx + 4, ty + 15, tagW - 8, 4, hpFrac,
                        Theme.alpha(Theme.TRACK_OFF, 0xFF), hpCol, false);
            }
        }
    }

    /** Same simplified projection as PlayerESP — documented there. */
    private int[] worldToScreen(Player p, int sw, int sh) {
        double dx = p.getX() - mc.player.getX();
        double dy = p.getEyeY() + p.getBbHeight() * 0.1 - mc.player.getEyeY();
        double dz = p.getZ() - mc.player.getZ();

        float yaw  = (float) Math.toRadians(mc.player.getYRot());
        float pitch= (float) Math.toRadians(mc.player.getXRot());
        double fx = -Math.sin(yaw) * Math.cos(pitch);
        double fy = -Math.sin(pitch);
        double fz =  Math.cos(yaw) * Math.cos(pitch);
        double dot = dx * fx + dy * fy + dz * fz;
        if (dot <= 0.5) return null;

        double rx = Math.cos(yaw), rz = Math.sin(yaw);
        double fovScale = sw / (2.0 * Math.tan(Math.toRadians(mc.options.fov().get() / 2.0)));

        int sx = (int)(sw / 2.0 + (dx * rx + dz * rz) / dot * fovScale);
        int sy = (int)(sh / 2.0 - dy / dot * fovScale);
        return new int[]{sx, sy};
    }
}
