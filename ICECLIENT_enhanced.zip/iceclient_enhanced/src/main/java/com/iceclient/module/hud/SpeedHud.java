package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Shows current horizontal movement speed (blocks/s) and an optional
 * mini-graph of the last 40 ticks.
 */
public final class SpeedHud extends Module {
    private final NumberSetting x       = add(new NumberSetting("X", "Left offset",   6, 0, 1920, 1));
    private final NumberSetting y       = add(new NumberSetting("Y", "Bottom offset", 50, 10, 400, 1));
    private final BooleanSetting graph  = add(new BooleanSetting("Graph", "Show speed history graph", true));

    private static final int HISTORY = 40;
    private final float[] speeds = new float[HISTORY];
    private int head = 0;
    private double lastX, lastZ;

    public SpeedHud() {
        super("SpeedHud", "Hien thi toc do di chuyen hien tai.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        double dx = mc.player.getX() - lastX;
        double dz = mc.player.getZ() - lastZ;
        lastX = mc.player.getX();
        lastZ = mc.player.getZ();
        float bps = (float)(Math.sqrt(dx * dx + dz * dz) * 20.0); // blocks/s
        speeds[head % HISTORY] = bps;
        head++;
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        if (mc.player == null) return;

        int idx = (head - 1 + HISTORY) % HISTORY;
        float current = speeds[idx];
        String text = String.format("%.2f b/s", current);

        int graphW = 80, graphH = 20;
        int panW = Math.max(70, Render2D.width(text) + 20);
        int panH = graph.on() ? graphH + 20 : 20;
        int px = x.i();
        int py = g.guiHeight() - y.i() - panH;

        Render2D.roundedPanel(g, px, py, panW, panH, 3, Theme.alpha(Theme.BG, 0xCC), Theme.BORDER);
        Render2D.rect(g, px + 1, py + 3, 2, panH - 6, Theme.PRIMARY);

        // Speed color based on walk/run threshold
        int speedColor = current < 0.1f ? Theme.MUTED
                       : current < 6f   ? Theme.OK
                       : current < 15f  ? Theme.WARN
                                        : Theme.DANGER;
        Render2D.shadowText(g, text, px + 8, py + 6, speedColor);

        // Graph
        if (graph.on()) {
            int gx = px + 4, gy = py + 18, gw = panW - 8;
            Render2D.rect(g, gx, gy, gw, graphH, Theme.alpha(Theme.TRACK_OFF, 0x80));

            float maxS = 0f;
            for (float s : speeds) if (s > maxS) maxS = s;
            if (maxS < 0.1f) maxS = 0.1f;

            for (int i = 0; i < HISTORY; i++) {
                int dataIdx = (head - HISTORY + i + HISTORY * 2) % HISTORY;
                float s = speeds[dataIdx];
                int barHeight = (int)(s / maxS * (graphH - 2));
                int bx = gx + i * gw / HISTORY;
                int bw = Math.max(1, gw / HISTORY - 1);
                int col = i == HISTORY - 1 ? Theme.PRIMARY : Theme.alpha(Theme.SECONDARY, 0x70);
                Render2D.rect(g, bx, gy + graphH - 1 - barHeight, bw, barHeight, col);
            }
        }
    }
}
