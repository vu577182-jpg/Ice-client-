package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Animation;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.List;

/**
 * Shows the nearest enemy player in view: name, health bar, armour bar.
 * Fades in/out when target is acquired/lost.
 */
public final class TargetHud extends Module {
    private final NumberSetting x    = add(new NumberSetting("X", "Left offset",  6, 0, 1920, 1));
    private final NumberSetting y    = add(new NumberSetting("Y", "Top offset",  48, 0, 1080, 1));
    private final NumberSetting range = add(new NumberSetting("Range", "Detection range", 32, 4, 64, 1));
    private final BooleanSetting showArm = add(new BooleanSetting("Armor",  "Show armour bar",  true));
    private final BooleanSetting glowTarget = add(new BooleanSetting("Glow", "Glow on panel",    true));

    private final Animation fadeAnim = new Animation(0f, 8f);
    private LivingEntity target;

    public TargetHud() {
        super("TargetHud", "Hien thi muc tieu dang tan cong.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) { target = null; return; }
        double rangeSq = range.d() * range.d();
        LivingEntity closest = null;
        double bestDist = Double.MAX_VALUE;
        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            double d = mc.player.distanceToSqr(p);
            if (d < rangeSq && d < bestDist) { bestDist = d; closest = p; }
        }
        target = closest;
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        fadeAnim.set(target != null ? 1f : 0f);
        float fade = fadeAnim.get();
        if (fade < 0.02f) return;

        LivingEntity t = target;
        if (t == null) return;

        int panW = 160, panH = showArm.on() ? 46 : 38;
        int px = x.i(), py = y.i();
        int alpha = (int)(0xD0 * fade);

        // Panel
        Render2D.roundedPanel(g, px, py, panW, panH, 5,
                Theme.alpha(Theme.BG, alpha), Theme.alpha(Theme.BORDER, alpha));
        if (glowTarget.on()) {
            int hp = (int)(t.getHealth() / t.getMaxHealth() * 100);
            int glowColor = Theme.health(t.getHealth() / t.getMaxHealth());
            Render2D.glowRounded(g, px, py, panW, panH, 5, 3,
                    Theme.alpha(glowColor, (int)(0x50 * fade)));
        }

        // Name
        String name = t.getName().getString();
        Render2D.shadowText(g, name, px + 10, py + 7, Theme.alpha(Theme.TEXT, (int)(0xFF * fade)));

        // Health fraction
        float hpFrac = t.getHealth() / t.getMaxHealth();
        String hpStr = String.format("%.1f / %.1f", t.getHealth(), t.getMaxHealth());
        Render2D.text(g, hpStr, px + panW - Render2D.width(hpStr) - 8, py + 7,
                Theme.alpha(Theme.health(hpFrac), (int)(0xFF * fade)));

        // HP bar
        Render2D.bar(g, px + 10, py + 20, panW - 20, 5, hpFrac,
                Theme.alpha(Theme.TRACK_OFF, (int)(0xFF * fade)),
                Theme.alpha(Theme.health(hpFrac), (int)(0xFF * fade)), true);

        // Armour bar
        if (showArm.on()) {
            float armFrac = getArmourFrac(t);
            Render2D.bar(g, px + 10, py + 32, panW - 20, 4, armFrac,
                    Theme.alpha(Theme.TRACK_OFF, (int)(0xFF * fade)),
                    Theme.alpha(Theme.ACCENT_ARM, (int)(0xCC * fade)), false);
            Render2D.text(g, "ARM", px + 10, py + 38,
                    Theme.alpha(Theme.MUTED, (int)(0xA0 * fade)));
        }

        // Ping (if player)
        if (t instanceof Player tp) {
            var info = mc.getConnection() == null ? null :
                    mc.getConnection().getPlayerInfo(tp.getUUID());
            if (info != null) {
                int ms = info.getLatency();
                String pingStr = ms + "ms";
                Render2D.text(g, pingStr, px + 10, py + (showArm.on() ? 38 : 30) - 1 ,
                        Theme.alpha(Theme.ping(ms), (int)(0xA0 * fade)));
            }
        }
    }

    private float getArmourFrac(LivingEntity e) {
        int total = 0, max = 0;
        for (var stack : e.getArmorSlots()) {
            if (!stack.isEmpty() && stack.isDamageableItem()) {
                total += (stack.getMaxDamage() - stack.getDamageValue());
                max   += stack.getMaxDamage();
            }
        }
        return max == 0 ? 0f : (float) total / max;
    }
}
