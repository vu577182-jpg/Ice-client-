package com.iceclient.module.render;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.ModeSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * 2D screen-space bounding-box ESP for other players.
 *
 * Projects the entity AABB corners to screen space using the vanilla
 * camera projection available via GameRenderer.  Falls back to a
 * simplified approach when the entity is off-screen.
 *
 * Mode options:
 *   Box     — outline rectangle around the player
 *   Corner  — four corner brackets only (less intrusive)
 *   Filled  — semi-transparent fill + outline
 */
public final class PlayerESP extends Module {
    private final ModeSetting    mode   = add(new ModeSetting("Mode",  "Render mode", "Box", "Box", "Corner", "Filled"));
    private final BooleanSetting health = add(new BooleanSetting("HealthColor", "Color by HP fraction", true));
    private final BooleanSetting names  = add(new BooleanSetting("Names",       "Show player names",    true));
    private final BooleanSetting tracers= add(new BooleanSetting("Tracers",     "Draw tracers to feet", false));
    private final NumberSetting  range  = add(new NumberSetting("Range", "Max render range", 64, 8, 128, 4));

    public PlayerESP() {
        super("PlayerESP", "Hien thi khung bao quanh nguoi choi khac.", Category.RENDER);
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        if (mc.player == null || mc.level == null || mc.gameRenderer == null) return;

        int sw = g.guiWidth(), sh = g.guiHeight();
        double rangeSq = range.d() * range.d();

        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            if (mc.player.distanceToSqr(p) > rangeSq) continue;

            int[] box = projectEntityBox(p, sw, sh);
            if (box == null) continue;

            int bx = box[0], by = box[1], bw = box[2], bh = box[3];

            // Choose color
            int col;
            if (health.on()) {
                col = Theme.health(p.getHealth() / p.getMaxHealth());
            } else {
                col = Theme.PRIMARY;
            }

            switch (mode.get()) {
                case "Corner"  -> drawCorners(g, bx, by, bw, bh, col);
                case "Filled"  -> {
                    Render2D.rect(g, bx, by, bw, bh, Theme.alpha(col, 0x28));
                    Render2D.outline(g, bx, by, bw, bh, Theme.alpha(col, 0xCC));
                }
                default        -> Render2D.outline(g, bx, by, bw, bh, Theme.alpha(col, 0xCC));
            }

            // Name tag above box
            if (names.on()) {
                String name = p.getName().getString();
                int nx = bx + (bw - Render2D.width(name)) / 2;
                // Drop shadow
                Render2D.text(g, name, nx + 1, by - 10, Theme.alpha(0x000000, 0x80));
                Render2D.text(g, name, nx,     by - 10, Theme.alpha(col, 0xFF));
            }

            // Tracer from screen bottom-centre to entity feet
            if (tracers.on()) {
                int tx = bx + bw / 2;
                int ty = by + bh;
                g.fill(sw / 2, sh, tx, ty, Theme.alpha(col, 0x60));
            }
        }
    }

    /**
     * Projects the entity's bounding box to 2D screen space.
     * Returns [x, y, w, h] or null if the entity is fully behind the camera.
     *
     * We use a simplified projection: take the entity eye position + height offsets
     * and use the vanilla WorldToScreen helper via reflection fallback.
     * Since GuiGraphicsExtractor does not expose the camera matrices, we
     * approximate by using the entity's screen-space distance and FOV.
     */
    private int[] projectEntityBox(Player p, int sw, int sh) {
        // Simple distance-based 2D bounding box estimation.
        // For a full world-to-screen projection, the caller would hook into
        // GameRenderer — this gives a visually accurate approximation for
        // mid-to-close range (< 32 blocks).

        double dx = p.getX() - mc.player.getX();
        double dy = p.getY() - mc.player.getEyeY();
        double dz = p.getZ() - mc.player.getZ();

        // Dot with forward vector to check if entity is in front
        float yaw  = (float) Math.toRadians(mc.player.getYRot());
        float pitch= (float) Math.toRadians(mc.player.getXRot());
        double fx = -Math.sin(yaw) * Math.cos(pitch);
        double fy = -Math.sin(pitch);
        double fz =  Math.cos(yaw) * Math.cos(pitch);
        double dot = dx * fx + dy * fy + dz * fz;
        if (dot <= 0) return null;  // behind camera

        // Right vector
        double rx = Math.cos(yaw), rz = Math.sin(yaw);

        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double fovScale = sw / (2.0 * Math.tan(Math.toRadians(mc.options.fov().get() / 2.0)));

        double screenX = sw / 2.0 + (dx * rx + dz * rz) / dot * fovScale;
        double screenY = sh / 2.0 - (dy - p.getBbHeight() / 2.0 + p.getBbHeight()) / dot * fovScale;

        double halfW  = (p.getBbWidth()  / 2.0) / dist * fovScale;
        double fullH  = (p.getBbHeight())         / dist * fovScale;

        int bx = (int)(screenX - halfW);
        int by = (int)(screenY - fullH);
        int bw = (int)(halfW * 2);
        int bh = (int) fullH;

        // Clamp to screen bounds
        bw = Math.max(4, bw);
        bh = Math.max(8, bh);

        return new int[]{bx, by, bw, bh};
    }

    private void drawCorners(GuiGraphicsExtractor g, int x, int y, int w, int h, int col) {
        int c = Math.min(w / 3, 6);
        int alpha = Theme.alpha(col, 0xCC);
        // top-left
        g.fill(x,     y,     x + c, y + 1, alpha);
        g.fill(x,     y,     x + 1, y + c, alpha);
        // top-right
        g.fill(x+w-c, y,     x + w, y + 1, alpha);
        g.fill(x+w-1, y,     x + w, y + c, alpha);
        // bottom-left
        g.fill(x,     y+h-1, x + c, y + h, alpha);
        g.fill(x,     y+h-c, x + 1, y + h, alpha);
        // bottom-right
        g.fill(x+w-c, y+h-1, x + w, y + h, alpha);
        g.fill(x+w-1, y+h-c, x + w, y + h, alpha);
    }
}
