package com.iceclient.module.render;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.ModeSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * 2D screen-space highlight for nearby storage containers.
 * Supported: Chest, Trapped Chest, Barrel, Shulker Box, Ender Chest.
 *
 * Uses the same simplified 2D projection as PlayerESP.
 */
public final class ChestESP extends Module {
    private final NumberSetting  range      = add(new NumberSetting("Range", "Scan radius (blocks)", 20, 4, 48, 2));
    private final ModeSetting    mode       = add(new ModeSetting("Mode", "Render mode", "Corner", "Box", "Corner"));
    private final BooleanSetting shulkers   = add(new BooleanSetting("Shulkers",    "Include shulker boxes",  true));
    private final BooleanSetting ender      = add(new BooleanSetting("EnderChest",  "Include ender chests",   true));
    private final BooleanSetting barrels    = add(new BooleanSetting("Barrels",     "Include barrels",        true));

    // Color per type
    private static final int COL_CHEST  = 0xFFE8B060;  // gold
    private static final int COL_SHULK  = 0xFFCE93D8;  // purple
    private static final int COL_ENDER  = 0xFF7B68EE;  // medium-slate
    private static final int COL_BARREL = 0xFFB0896A;  // brown

    public ChestESP() {
        super("ChestESP", "Hien thi vi tri rung va hop luu tru.", Category.RENDER);
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        if (mc.player == null || mc.level == null) return;
        int sw = g.guiWidth(), sh = g.guiHeight();

        // Collect nearby block entities
        List<BlockPos> targets = new ArrayList<>();
        List<Integer>  colors  = new ArrayList<>();

        int r = range.i();
        BlockPos origin = mc.player.blockPosition();

        for (BlockPos pos : BlockPos.betweenClosed(
                origin.offset(-r, -r, -r), origin.offset(r, r, r))) {
            if (!mc.level.isLoaded(pos)) continue;
            Block b = mc.level.getBlockState(pos).getBlock();
            int col = -1;

            if (b instanceof ChestBlock || b instanceof TrappedChestBlock) {
                col = COL_CHEST;
            } else if (shulkers.on() && b instanceof ShulkerBoxBlock) {
                col = COL_SHULK;
            } else if (ender.on() && b instanceof EnderChestBlock) {
                col = COL_ENDER;
            } else if (barrels.on() && b instanceof BarrelBlock) {
                col = COL_BARREL;
            }

            if (col != -1) {
                targets.add(pos.immutable());
                colors.add(col);
            }
        }

        for (int i = 0; i < targets.size(); i++) {
            BlockPos pos  = targets.get(i);
            int col       = colors.get(i);
            int[] screen  = blockToScreen(pos, sw, sh);
            if (screen == null) continue;

            int bx = screen[0] - 8, by = screen[1] - 8, bw = 16, bh = 16;

            if ("Corner".equals(mode.get())) {
                drawCorners(g, bx, by, bw, bh, col);
            } else {
                Render2D.outline(g, bx, by, bw, bh, Theme.alpha(col, 0xCC));
                Render2D.rect(g, bx + 1, by + 1, bw - 2, bh - 2, Theme.alpha(col, 0x20));
            }
        }
    }

    private int[] blockToScreen(BlockPos pos, int sw, int sh) {
        double dx = pos.getX() + 0.5 - mc.player.getX();
        double dy = pos.getY() + 0.5 - mc.player.getEyeY();
        double dz = pos.getZ() + 0.5 - mc.player.getZ();

        float yaw  = (float) Math.toRadians(mc.player.getYRot());
        float pitch= (float) Math.toRadians(mc.player.getXRot());
        double fx = -Math.sin(yaw) * Math.cos(pitch);
        double fy = -Math.sin(pitch);
        double fz =  Math.cos(yaw) * Math.cos(pitch);
        double dot = dx * fx + dy * fy + dz * fz;
        if (dot <= 0.3) return null;

        double rx = Math.cos(yaw), rz = Math.sin(yaw);
        double fovScale = sw / (2.0 * Math.tan(Math.toRadians(mc.options.fov().get() / 2.0)));

        int sx = (int)(sw / 2.0 + (dx * rx + dz * rz) / dot * fovScale);
        int sy = (int)(sh / 2.0 - dy / dot * fovScale);
        return new int[]{sx, sy};
    }

    private void drawCorners(GuiGraphicsExtractor g, int x, int y, int w, int h, int col) {
        int c = Math.min(w / 3, 5);
        int a = Theme.alpha(col, 0xCC);
        g.fill(x,     y,     x+c, y+1, a); g.fill(x,     y,     x+1, y+c, a);
        g.fill(x+w-c, y,     x+w, y+1, a); g.fill(x+w-1, y,     x+w, y+c, a);
        g.fill(x,     y+h-1, x+c, y+h, a); g.fill(x,     y+h-c, x+1, y+h, a);
        g.fill(x+w-c, y+h-1, x+w, y+h, a); g.fill(x+w-1, y+h-c, x+w, y+h, a);
    }
}
