package com.iceclient.module.client;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import net.minecraft.client.gui.screens.Screen;

public final class ClickGui extends Module {
    /** Dim the game world when the GUI is open. */
    public final BooleanSetting dim    = add(new BooleanSetting("Dim",    "Fade the background when GUI is open", true));
    /** Show animated ice crystal decorations in the GUI corners. */
    public final BooleanSetting ice    = add(new BooleanSetting("Ice",    "Animated ice crystal decorations",     true));
    /** Rainbow / chroma colour mode for logo and frame border. */
    public final BooleanSetting chroma = add(new BooleanSetting("Chroma", "Rainbow chroma colour on logo/border", false));

    public ClickGui() {
        super("ClickGui", "Mo giao dien dieu chinh module.", Category.CLIENT);
    }

    @Override protected boolean requiresWorld()   { return false; }
    @Override public    boolean isHidden()         { return true; }

    @Override
    protected void onEnable() {
        if (mc.screen == null) {
            mc.setScreen(new com.iceclient.gui.IceScreen());
        }
        setEnabledSilently(false);
    }
}
