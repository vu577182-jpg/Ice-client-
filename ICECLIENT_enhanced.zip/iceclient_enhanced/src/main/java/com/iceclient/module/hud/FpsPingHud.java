package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ClientPacketListener;

/** Displays current FPS and server ping with a small colour-coded bar. */
public final class FpsPingHud extends Module {
    private final NumberSetting x    = add(new NumberSetting("X", "Horizontal offset", 6, 0, 1920, 1));
    private final NumberSetting y    = add(new NumberSetting("Y", "Vertical offset",   30, 0, 1080, 1));
    private final BooleanSetting showBar = add(new BooleanSetting("PingBar", "Show ping colour bar", true));
    private final BooleanSetting glow    = add(new BooleanSetting("Glow",    "Glow on panel border", true));

    public FpsPingHud() {
        super("FpsPing", "Hien thi FPS va Ping voi thanh chi so.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override protected boolean requiresWorld() { return false; }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        int fps = mc.getFps();
        int ping = getPing();

        String fpsStr  = "FPS " + fps;
        String pingStr = "PING " + (ping < 0 ? "---" : ping + "ms");

        int panW = Math.max(Render2D.width(fpsStr), Render2D.width(pingStr)) + 20;
        int panH = showBar.on() ? 36 : 28;
        int px   = x.i(), py = y.i();

        // Background panel
        Render2D.roundedPanel(g, px, py, panW, panH, 4, Theme.alpha(Theme.BG, 0xD8), Theme.BORDER);
        if (glow.on()) Render2D.glowRounded(g, px, py, panW, panH, 4, 2, Theme.PRIMARY);

        // Accent bar on the left
        Render2D.rect(g, px + 1, py + 3, 2, panH - 6, Theme.PRIMARY);

        // FPS text
        int fpsColor = fps >= 60 ? Theme.OK : fps >= 30 ? Theme.WARN : Theme.DANGER;
        Render2D.shadowText(g, fpsStr,  px + 8, py + 5,  fpsColor);
        Render2D.shadowText(g, pingStr, px + 8, py + 16, Theme.ping(ping));

        // Ping bar
        if (showBar.on() && ping >= 0) {
            float t = Math.max(0f, Math.min(1f, 1f - ping / 300f));
            Render2D.bar(g, px + 8, py + 28, panW - 16, 4, t,
                    Theme.alpha(Theme.TRACK_OFF, 0xFF),
                    Theme.ping(ping), false);
        }
    }

    private int getPing() {
        ClientPacketListener conn = mc.getConnection();
        if (conn == null || mc.player == null) return -1;
        var info = conn.getPlayerInfo(mc.player.getUUID());
        return info == null ? -1 : info.getLatency();
    }
}
