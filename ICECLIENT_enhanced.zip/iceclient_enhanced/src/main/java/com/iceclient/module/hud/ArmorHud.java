package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.ModeSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Shows equipped armour pieces (helmet → boots, left to right) with
 * durability bars beneath each slot.
 */
public final class ArmorHud extends Module {
    private final NumberSetting x       = add(new NumberSetting("X", "Left offset",   6, 0, 1920, 1));
    private final NumberSetting yBottom = add(new NumberSetting("Y", "Bottom offset", 76, 0, 400,  1));
    private final BooleanSetting showDur = add(new BooleanSetting("Durability", "Show durability bars",  true));
    private final BooleanSetting showNum = add(new BooleanSetting("Numbers",    "Show durability numbers", false));
    private final ModeSetting    order   = add(new ModeSetting("Order", "Slot order", "HeadFirst", "HeadFirst", "FeetFirst"));

    // MC armour slot indices: 3=helmet, 2=chest, 1=legs, 0=boots
    private static final int[] SLOTS_HEAD_FIRST = {3, 2, 1, 0};
    private static final int[] SLOTS_FEET_FIRST = {0, 1, 2, 3};

    public ArmorHud() {
        super("ArmorHud", "Hien thi giap va do ben tren HUD.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        if (mc.player == null) return;

        int[] slots = order.is("FeetFirst") ? SLOTS_FEET_FIRST : SLOTS_HEAD_FIRST;
        int slotSize = 18, gap = 2;
        int barH = showDur.on() ? 4 : 0;
        int panH = slotSize + barH + (showNum.on() ? 10 : 0) + 6;
        int panW = slots.length * (slotSize + gap) - gap + 8;

        int px = x.i();
        int py = g.guiHeight() - yBottom.i() - panH;

        Render2D.roundedPanel(g, px, py, panW, panH, 3, Theme.alpha(Theme.BG, 0xCC), Theme.BORDER);
        Render2D.rect(g, px + 1, py + 2, 2, panH - 4, Theme.ACCENT_ARM);

        int ix = px + 4;
        for (int idx : slots) {
            ItemStack stack = mc.player.getInventory().armor.get(idx);

            // Draw item icon (slot bg if empty)
            if (stack.isEmpty()) {
                Render2D.rect(g, ix, py + 3, slotSize, slotSize, Theme.alpha(Theme.TRACK_OFF, 0x80));
                Render2D.outline(g, ix, py + 3, slotSize, slotSize, Theme.alpha(Theme.BORDER, 0xA0));
            } else {
                g.renderItem(stack, ix, py + 3);
            }

            // Durability bar
            if (showDur.on() && !stack.isEmpty() && stack.isDamageableItem()) {
                float frac = 1f - (float) stack.getDamageValue() / stack.getMaxDamage();
                int barY = py + 3 + slotSize + 1;
                Render2D.bar(g, ix, barY, slotSize, 3, frac,
                        Theme.alpha(Theme.TRACK_OFF, 0xFF),
                        Theme.health(frac), false);
            }

            // Numeric durability
            if (showNum.on() && !stack.isEmpty() && stack.isDamageableItem()) {
                int remaining = stack.getMaxDamage() - stack.getDamageValue();
                String s = remaining > 999 ? remaining / 100 + "k" : String.valueOf(remaining);
                Render2D.centeredText(g, s, ix + slotSize / 2,
                        py + 3 + slotSize + (showDur.on() ? 6 : 2),
                        Theme.MUTED);
            }

            ix += slotSize + gap;
        }
    }
}
