package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Displays active potion effects as compact rows on the HUD.
 * Each row shows: effect name, amplifier (II/III …), and remaining time.
 * Effects below 5 s flash to indicate expiry.
 */
public final class PotionHud extends Module {
    private final NumberSetting x    = add(new NumberSetting("X", "Left offset",  6, 0, 1920, 1));
    private final NumberSetting y    = add(new NumberSetting("Y", "Top offset",  60, 0, 1080, 1));
    private final BooleanSetting glow = add(new BooleanSetting("Glow", "Glow on panel", false));

    public PotionHud() {
        super("PotionHud", "Hien thi hieu ung thuoc dang hoat dong.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        if (mc.player == null) return;

        List<MobEffectInstance> effects = new ArrayList<>(mc.player.getActiveEffects());
        if (effects.isEmpty()) return;

        // Sort: beneficial first, then by remaining duration descending
        effects.sort(Comparator.comparingInt((MobEffectInstance e) ->
                e.getEffect().value().isBeneficial() ? 0 : 1)
                .thenComparingInt(e -> -e.getDuration()));

        int rowH = 14, padX = 8, padY = 4;
        int panW = 110;
        int panH = effects.size() * rowH + padY * 2;

        int px = x.i(), py = y.i();
        Render2D.roundedPanel(g, px, py, panW, panH, 4, Theme.alpha(Theme.BG, 0xD0), Theme.BORDER);
        if (glow.on()) Render2D.glowRounded(g, px, py, panW, panH, 4, 2, Theme.ACCENT_FX);

        int ry = py + padY;
        for (MobEffectInstance inst : effects) {
            MobEffect effect = inst.getEffect().value();

            // Flash when < 5 s
            int ticks = inst.getDuration();
            boolean flash = ticks < 100 && (System.currentTimeMillis() / 300) % 2 == 0;
            if (flash) { ry += rowH; continue; }

            int nameColor = effect.isBeneficial() ? Theme.OK : Theme.DANGER;
            String name = formatEffectName(effect);
            if (inst.getAmplifier() > 0) name += " " + toRoman(inst.getAmplifier() + 1);
            String time = formatTicks(ticks);

            // Left accent dot
            Render2D.rect(g, px + 3, ry + 4, 2, 6, nameColor);

            Render2D.text(g, name, px + padX, ry + 3, nameColor);
            Render2D.text(g, time, px + panW - Render2D.width(time) - padX, ry + 3, Theme.MUTED);
            ry += rowH;
        }
    }

    private static String formatEffectName(MobEffect effect) {
        // Pull the last segment of the translation key as short name
        String key = effect.getDescriptionId();
        int dot = key.lastIndexOf('.');
        String raw = dot >= 0 ? key.substring(dot + 1) : key;
        return raw.length() > 1 ? Character.toUpperCase(raw.charAt(0)) + raw.substring(1) : raw;
    }

    private static String formatTicks(int ticks) {
        if (ticks < 0 || ticks > 72000) return "inf";
        int s = ticks / 20;
        if (s >= 60) return (s / 60) + "m" + (s % 60 == 0 ? "" : (s % 60) + "s");
        return s + "s";
    }

    private static String toRoman(int n) {
        return switch (n) {
            case 2 -> "II"; case 3 -> "III"; case 4 -> "IV";
            case 5 -> "V";  default -> String.valueOf(n);
        };
    }
}
