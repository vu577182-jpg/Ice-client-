#!/usr/bin/env python3
"""Pulls the official Fabric build scripts, pins the versions for Minecraft 26.1.2 and prepares Gradle."""
import json, os, re, shutil, subprocess, sys, urllib.request, xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
MC = "26.1.2"

def get(url):
    with urllib.request.urlopen(url, timeout=30) as r:
        return r.read().decode()

def sh(*cmd, check=True):
    print("$", " ".join(cmd))
    return subprocess.run(cmd, check=check)

# ---- versions -------------------------------------------------------------
games = json.loads(get("https://meta.fabricmc.net/v2/versions/game"))
names = [g["version"] for g in games]
if MC not in names:
    print(f"[ERR] Fabric meta chua co Minecraft {MC}. Ban 26.x moi nhat: {[n for n in names if n.startswith('26')][:6]}")
    sys.exit(1)
loaders = json.loads(get("https://meta.fabricmc.net/v2/versions/loader"))
loader = next(l["version"] for l in loaders if l.get("stable"))
meta = ET.fromstring(get("https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/maven-metadata.xml"))
api_versions = [v.text for v in meta.iter("version") if v.text.endswith("+" + MC)]
if not api_versions:
    print(f"[ERR] Khong co Fabric API cho {MC}")
    sys.exit(1)
fabric_api = api_versions[-1]
print(f"[OK] Minecraft {MC} | Loader {loader} | Fabric API {fabric_api}")

# ---- template ---------------------------------------------------------------
shutil.rmtree(".template", ignore_errors=True)
cloned = False
for branch in (MC, "26.1", "26.1.2", None):
    cmd = ["git", "clone", "--depth", "1"] + (["--branch", branch] if branch else []) + \
          ["https://github.com/FabricMC/fabric-example-mod", ".template"]
    if subprocess.run(cmd).returncode == 0:
        print(f"[OK] Template branch: {branch or 'default'}")
        cloned = True
        break
if not cloned:
    print("[ERR] Khong clone duoc fabric-example-mod")
    sys.exit(1)

for item in ("gradlew", "gradlew.bat", "gradle", "build.gradle", "settings.gradle", "gradle.properties"):
    src = os.path.join(".template", item)
    if not os.path.exists(src):
        continue
    if os.path.isdir(src):
        shutil.rmtree(item, ignore_errors=True)
        shutil.copytree(src, item)
    else:
        shutil.copy2(src, item)
os.chmod("gradlew", 0o755)
shutil.rmtree(".template", ignore_errors=True)

# ---- gradle.properties -----------------------------------------------------
props = open("gradle.properties").read()
def setprop(text, key_regex, key, value):
    if re.search(rf"^{key_regex}\s*=", text, re.M):
        return re.sub(rf"^({key_regex})\s*=.*$", rf"\1={value}", text, flags=re.M)
    return text.rstrip("\n") + f"\n{key}={value}\n"
props = setprop(props, "minecraft_version", "minecraft_version", MC)
props = setprop(props, "loader_version", "loader_version", loader)
props = setprop(props, r"fabric(?:_api)?_version", "fabric_api_version", fabric_api)
props = setprop(props, "mod_version", "mod_version", "1.0.0")
props = setprop(props, "maven_group", "maven_group", "com.iceclient")
props = setprop(props, "archives_base_name", "archives_base_name", "ICECLIENT")
open("gradle.properties", "w").write(props)

# ---- build.gradle: everything lives in src/main (no split client source set) -------
def strip_block(text, header_regex):
    m = re.search(header_regex, text)
    while m:
        i = text.index("{", m.start())
        depth, j = 0, i
        while j < len(text):
            if text[j] == "{": depth += 1
            elif text[j] == "}":
                depth -= 1
                if depth == 0: break
            j += 1
        text = text[:m.start()] + text[j + 1:]
        m = re.search(header_regex, text)
    return text

gradle = open("build.gradle").read()
gradle = re.sub(r"^\s*splitEnvironmentSourceSets\(\)\s*$", "", gradle, flags=re.M)
gradle = strip_block(gradle, r"(?m)^\s*mods\s*\{")
open("build.gradle", "w").write(gradle)

print("\n===== gradle.properties =====\n" + open("gradle.properties").read())
print("===== build.gradle =====\n" + gradle)
print("[OK] Bootstrap xong. Chay tiep: bash scripts/03_build.sh")
