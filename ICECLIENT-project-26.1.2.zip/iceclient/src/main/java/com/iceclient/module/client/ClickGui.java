package com.iceclient.module.client;

import com.iceclient.gui.IceScreen;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;

/** Opens the ICECLIENT menu. Default keybind: Right Shift. */
public final class ClickGui extends Module {
    public final BooleanSetting ice = add(new BooleanSetting("IceCrystals", "Draw ice crystals on the four corners of the menu frame", true));
    public final BooleanSetting dim = add(new BooleanSetting("DimBackground", "Darken the game behind the menu", true));

    public ClickGui() {
        super("ClickGUI", "Mo menu ICECLIENT.", Category.CLIENT);
        setKey(344);
    }

    @Override
    protected void onEnable() {
        mc.gui.setScreen(new IceScreen());
        // This is a trigger, not a persistent state.
        setEnabledSilently(false);
    }
}
