package com.iceclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class Render2D {
    private Render2D() {}

    public static void rect(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        if (w <= 0 || h <= 0) return;
        g.fill(x, y, x + w, y + h, color);
    }

    public static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y + 1, x + 1, y + h - 1, color);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    /** Rectangle with 1px chamfered corners (cheap "rounded" look). */
    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, int bg, int border) {
        if (w < 4 || h < 4) { rect(g, x, y, w, h, bg); return; }
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, bg);
        g.fill(x + 1, y, x + w - 1, y + 1, border);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h, border);
        g.fill(x, y + 1, x + 1, y + h - 1, border);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, border);
    }

    public static void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(Minecraft.getInstance().font, s, x, y, color, false);
    }

    public static void shadowText(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(Minecraft.getInstance().font, s, x, y, color, true);
    }

    public static int width(String s) { return Minecraft.getInstance().font.width(s); }

    public static String trim(String s, int maxWidth) {
        if (width(s) <= maxWidth) return s;
        while (s.length() > 1 && width(s + "...") > maxWidth) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    /** Faceted vertical ice shard centred on (cx, cy). */
    public static void shard(GuiGraphicsExtractor g, int cx, int cy, int hw, int hh, int alpha) {
        int body = Theme.alpha(0x7FD0FF, alpha);
        int facet = Theme.alpha(0xFFFFFF, alpha / 2);
        for (int r = -hh; r <= hh; r++) {
            int w = (int) Math.round(hw * (1.0 - (double) Math.abs(r) / (hh + 1)));
            if (w <= 0) continue;
            g.fill(cx - w, cy + r, cx + w + 1, cy + r + 1, body);
            g.fill(cx - w, cy + r, cx, cy + r + 1, facet);
        }
        g.fill(cx, cy - hh, cx + 1, cy + hh + 1, Theme.alpha(0xFFFFFF, Math.min(255, alpha + 16)));
    }
}
