package com.iceclient.util;

/** ICE PRO palette (ARGB). */
public final class Theme {
    public static final int BG = 0xFF080D16;
    public static final int BG_LIGHT = 0xFF0C1422;
    public static final int CARD = 0xFF0E1726;
    public static final int CARD_HOVER = 0xFF132036;
    public static final int PRIMARY = 0xFF55BFFF;
    public static final int SECONDARY = 0xFFA8DFFF;
    public static final int BORDER = 0xFF263D55;
    public static final int TEXT = 0xFFEAF6FF;
    public static final int MUTED = 0xFF7E93AB;
    public static final int TRACK_OFF = 0xFF1B2A3E;
    public static final int WARN = 0xFFFFC857;
    public static final int DANGER = 0xFFFF6B7A;
    public static final int OK = 0xFF6BFFB0;

    private Theme() {}

    public static int alpha(int rgb, int a) { return ((a & 0xFF) << 24) | (rgb & 0xFFFFFF); }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int ar = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int ab = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }
}
